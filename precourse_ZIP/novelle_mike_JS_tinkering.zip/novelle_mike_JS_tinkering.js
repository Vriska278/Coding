var childheight = 1
function displayifchildisabletoridetherollercoaster(height){
    if (height >= 52){
        console.log("get on that ride kiddo!");
    }  
    else{
        console.log("sorry kiddo maybe next year");
    }
}
displayifchildisabletoridetherollercoaster(childheight);