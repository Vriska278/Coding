var riderHeight = 42;
var riderAge = 6;
function checkHeightAndAge(){
    if(riderAge >= 10 && riderHeight >= 42)
    {
        console.log("Come on aboard the coaster!")
    }
    else
    {
        console.log("Sorry shrimp maybe next time")
}}checkHeightAndAge() 
