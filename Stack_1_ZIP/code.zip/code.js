// set the amount of likes that were recieved
var likeCount = 0;
// adding a like to the total like count everytime it is run
function increaseLikes() {
    // updating the value of a variable by adding another variable to it as well as a single integer each time the program is run

    likeCount = likeCount + 1;
}
