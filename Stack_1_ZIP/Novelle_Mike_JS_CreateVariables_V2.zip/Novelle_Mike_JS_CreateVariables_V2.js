// var riderHeight = 42;
// var riderAge = 10;
function checkHeightAndAge(riderAge, riderHeight)
{
    if(riderAge >= 10 && riderHeight >= 42)
    {
        console.log("Come on aboard the coaster!");
    }
    else
    {
        console.log("Sorry shrimp maybe next time");
    }
}
checkHeightAndAge(10, 41);
