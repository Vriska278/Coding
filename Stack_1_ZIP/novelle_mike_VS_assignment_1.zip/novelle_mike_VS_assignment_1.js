console.log("i got a rainbow");
console.log("And an extension called bracket pair color DWL");